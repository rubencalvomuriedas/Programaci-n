public class MinimoCuenta extends RuntimeException {
    public MinimoCuenta(String message) {
        super(message);
    }
}