public class LimiteHacienda extends Exception {
    public LimiteHacienda(String mensaje) {
        super(mensaje);
    }
}
