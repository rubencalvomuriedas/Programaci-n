public class AvisarHaciendaException extends Exception {
    public AvisarHaciendaException(String message) {
        super(message);
    }
}
