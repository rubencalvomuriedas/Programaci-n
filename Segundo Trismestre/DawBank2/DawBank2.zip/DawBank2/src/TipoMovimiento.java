public enum TipoMovimiento {
    Ingreso, Retirada
}
