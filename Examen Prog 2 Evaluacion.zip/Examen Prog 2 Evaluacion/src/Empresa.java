public class Empresa {
}
