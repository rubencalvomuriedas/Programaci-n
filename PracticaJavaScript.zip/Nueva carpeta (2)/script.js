console.log("mi script funciona");

const pepino = document.getElementById('boton');

const lechuga = document.getElementById('mensaje');

boton.addEventListener('click', () => {
console.log('¡El botón fue presionado!');
});


pepino.addEventListener('click', () => {
lechuga.textContent = 'RUBEN CALVO MURIEDAS';
});
