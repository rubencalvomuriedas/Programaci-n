public class Enums {

    public enum Genero {
        ACCION, COMEDIA, DRAMA, TERROR, ANIMACION, SCIFI, ROMANCE
    }

}