public enum Tipo {
    PERRO, GATO, LORO, CANARIO
}
