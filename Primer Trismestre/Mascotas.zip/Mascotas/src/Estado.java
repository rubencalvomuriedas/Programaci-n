public enum Estado {
    BIEN, MAL, ENFERMO, CANSADO, MUERTO
}
