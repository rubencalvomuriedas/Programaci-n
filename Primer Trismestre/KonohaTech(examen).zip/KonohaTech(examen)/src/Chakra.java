public enum Chakra {
    TIERRA, FUEGO, AIRE, AGUA, RAYO
}
