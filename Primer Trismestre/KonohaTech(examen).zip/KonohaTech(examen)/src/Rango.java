public enum Rango {
    Genin, CHUNIN, JONIN, AMBU, KAGE
}
