import java.time.LocalDate;

public class Sensei {

}
