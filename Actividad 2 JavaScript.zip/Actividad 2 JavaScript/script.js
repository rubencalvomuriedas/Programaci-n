const inputNum1 = document.getElementById("num1");
const inputnum2 = document.getElementById("num2")


const btnSumar = document.getElementById("btnSumar");
const btnRestar = document.getElementById("btnRestar");
const btnMultiplicar = document.getElementById("btnMultiplicar");
const btnDividir = document.getElementById("btnDividir");
const btnLimpiar = document.getElementById("btnLimpiar");


const salidaResultado = document.getElementById("resultado");
const salidaMensaje = document.getElementById("mensaje");

/**paso2
funcuion leer numeros*/
function leerNumeros() {

//convertimos los valores de texto en numeros
const n1 = Number(inputNum1.value);
const n2 = Number(inputnum2.value);

//comprobamos si alguno NO es un numero válido
if (isNaN(n1) || isNaN(n2)) {

//si hay erros, devolvemos null
return null;
}

//si todo esta correcto, devolvemos ambos numeros
return {
n1: n1,
n2: n2
};
}

/*paso3
funciones*/
//Funcion suma
function sumar(a, b) {
return a + b;
}

//funcion resta
function restar(a, b) {
return a - b
}

//funcion multiplicar
function multiplicar(a, b) {
return a * b
}

//funcion division
function dividir(a, b) {

//no se puede dividir entre 0
if (b === 0) {
return null;
}

return a / b;
}

/*paso 4
funcion para mostrar datos en pantalla*/

function mostrarSalida(valor, mensaje) {

//si no nos pasan mensaje, usamos texto vacío
if (mensaje === undefined) {
mensaje = "";
}

//mostrar resultado
salidaResultado.textContent = valor;

//mostrar mensje
salidaMensaje.textContent = mensaje;
}

/*paso5
funcion general que ejecuta cualquier operacion*/

function ejecutarOperacion(operacion) {

//leemos los numeros
const datos = leerNumeros();

//si hay error al leer
if (datos === null) {

mostrarSalida("-", "Debes introducir dos numeros validos");

//salimos de la funciones
return;
}
//sacamos los valores del objeto
const n1 = datos.n1;
const n2 = datos.n2;

//ejecutamos la funcion recibida
const resultado = operacion(n1, n2);

//si la operacion devielve null (error)
if (resultado === null) {

mostrarSalida("-", "no se puede realizar esta operacion");

return;
}

//si todo ha ido bien
mostrarSalida(resultado, "operación realizada correctamente");
}

/*paso6
programos los eventos de los botones*/

btnSumar.addEventListener("click", function () {

ejecutarOperacion(sumar);
});

btnRestar.addEventListener("click", function (){

ejecutarOperacion(restar);

});

//boton multiplicar
btnMultiplicar.addEventListener("click", function (){

ejecutarOperacion(multiplicar);

});

//boton dividir
btnDividir.addEventListener("click", function (){

ejecutarOperacion(dividir);

});

/*paso7
boton limpiar*/

btnLimpiar.addEventListener("click", function (){

//vaciar inputs
inputNum1.value = "";
inputnum2.value = "";

//limpiar salida
mostrarSalida("-", "");

//colocarf el cursor en el primer input
});

/*paso8
estado inicial al cargar la pagina*/

mostrarSalida("-", "introduce dos numeros y seleccion una operacion");